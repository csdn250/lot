package com.example.tentest01;

public class AnaDataBean {
    private int Temp;//温度
    private int Humidity;//湿度

    public int getTemp() {
        return Temp;
    }

    public void setTemp(int temp) {
        Temp = temp;
    }

    public int getHumidity() {
        return Humidity;
    }

    public void setHumidity(int humidity) {
        Humidity = humidity;
    }
}
